### Generate .py from .ui
* `pyuic4 xxx.ui -o xxx.py`

How to run and open your SDK code ?
1. Open terminal
2. Input "cd Desktop/Scannel\ Inventory\ Software\ New/"
3. Input "python Main.py"

And the program will start with the file "Main.py"